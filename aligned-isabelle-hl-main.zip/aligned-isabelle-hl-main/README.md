# aligned-isabelle-hl
